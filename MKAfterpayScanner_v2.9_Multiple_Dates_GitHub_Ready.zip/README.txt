MKAfterpayScanner v2.9 Multiple Dates (Android source package)

Upload the extracted CONTENTS of this ZIP into the root of your MKAPSCanner GitHub repository. Do NOT upload only the ZIP if you want the supplied workflow to build it.

To replace YAML by hand, copy .github/workflows/main.yml into that same path in GitHub.

GitHub Actions > Build MKAfterpayScanner v2.9 APK > Run workflow, then download the APK from the run's Artifacts.

NOTE: Offline OCR requires locally bundled Tesseract worker/core/language files in app/src/main/assets/ocr/. Those files are not included. The HTML tries to load OCR from a CDN if local files are missing, so internet is needed for OCR with this package. Manual text entry works offline. This has not been compiled on GitHub.
