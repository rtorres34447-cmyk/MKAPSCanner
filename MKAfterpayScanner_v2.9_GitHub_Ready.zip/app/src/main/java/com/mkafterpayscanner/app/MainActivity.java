package com.mkafterpayscanner.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.*;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.Text;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<android.net.Uri[]> pendingFiles;
  private static final int PICK_IMAGES = 1021;
  private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    web = new WebView(this);
    web.setBackgroundColor(0xff081423);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.getSettings().setAllowContentAccess(true);
    web.addJavascriptInterface(new Bridge(), "NativeOCR");
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<android.net.Uri[]> callback, FileChooserParams params) {
        if(pendingFiles!=null) pendingFiles.onReceiveValue(null);
        pendingFiles=callback;
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        startActivityForResult(intent,PICK_IMAGES);
        return true;
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int req,int result,Intent data) {
    super.onActivityResult(req,result,data);
    if(req!=PICK_IMAGES || pendingFiles==null)return;
    android.net.Uri[] uris=null;
    if(result==RESULT_OK && data!=null) {
      if(data.getClipData()!=null){int count=data.getClipData().getItemCount();uris=new android.net.Uri[count];for(int i=0;i<count;i++)uris[i]=data.getClipData().getItemAt(i).getUri();}
      else if(data.getData()!=null)uris=new android.net.Uri[]{data.getData()};
    }
    pendingFiles.onReceiveValue(uris);pendingFiles=null;
  }
  private void fire(String name, String id, JSONObject payload) {
    String script="window."+name+"("+JSONObject.quote(id)+","+payload.toString()+")";
    runOnUiThread(()->web.evaluateJavascript(script,null));
  }
  final class Bridge {
    @JavascriptInterface public void scan(String dataUrl,String id){
      try {
        String data=dataUrl.substring(dataUrl.indexOf(',')+1);
        byte[] bytes=Base64.decode(data,Base64.DEFAULT);
        Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
        if(bitmap==null)throw new IllegalArgumentException("Cannot decode screenshot");
        recognizer.process(InputImage.fromBitmap(bitmap,0))
          .addOnSuccessListener(result->{
            try {
              JSONArray arr=new JSONArray();
              for(Text.TextBlock block:result.getTextBlocks())for(Text.Line line:block.getLines()){
                JSONObject item=new JSONObject();item.put("text",line.getText());
                if(line.getBoundingBox()!=null){item.put("y",line.getBoundingBox().top);item.put("x",line.getBoundingBox().left);}
                arr.put(item);
              }
              JSONObject payload=new JSONObject();payload.put("lines",arr);fire("onNativeScan",id,payload);
            }catch(Exception e){error(id,e.toString());}
          }).addOnFailureListener(e->error(id,e.getMessage()));
      } catch(Exception e){error(id,e.toString());}
    }
    private void error(String id,String reason){try{JSONObject p=new JSONObject();p.put("error",reason);fire("onNativeScan",id,p);}catch(Exception ignored){}}
  }
  @Override protected void onDestroy(){recognizer.close();web.destroy();super.onDestroy();}
}
