# MKAfterpayScanner v2.9

Standalone Android offline screenshot OCR app. Package: `com.mkafterpayscanner.app`.

## GitHub phone upload
1. Upload `MKAfterpayScanner_v2.9_GitHub_Ready.zip` to the repository **root** (Code > Add file > Upload files), without extracting it.
2. Create or update `.github/workflows/build-apk.yml` with the separately provided YAML text. GitHub's mobile web editor supports a new file via Add file > Create new file.
3. Go to Actions > Build MKAfterpayScanner v2.9 APK > Run workflow; download artifact `MKAfterpayScanner-v2.9-debug` when green.

Do not upload the ZIP inside a subfolder or use the wrong repo. The workflow extracts it automatically.

## Behaviour
- OCR is performed by the **bundled** ML Kit Latin text model on device; internet is not required to run OCR.
- Stop Scan stops the queue and discards callbacks from a stopped run, retaining completed results and images.
- Clear Attachments confirms, clears selected screenshots and current results, and preserves saved identifications.
- Unidentified repayments default to a list of saved identifications, with a `+ Add new` option.
- Only identified, non-duplicate records on the selected date count towards the total.
- Duplicate detection is heuristic (date + amount + OCR context), so confirm entries manually.
- Decimal-sensitive: $ amounts without a decimal point are not accepted, preventing false positive OCR totals.
- Data privacy: images and OCR text are processed locally; merchant labels saved only to local WebView storage.

## Known limitations
- This is a newly assembled v2.9 project, not a byte-for-byte patch of the previous v2.8 sources.
- Identical legitimate repayments may be flagged as duplicates. Screenshot OCR may miss repayments or dates. Review totals before relying on them.
- Some long screenshots may need splitting for OCR legibility.
- This unsigned debug build can usually install as an upgrade only when signing keys match. If v2.8 had a different debug signing key, Android may require uninstalling it first; saved data is then lost. Back up existing data beforehand.
