package com.mkap.scanner;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.*;
import android.net.Uri;
import android.view.View;
import android.widget.*;
import android.graphics.Bitmap;
public class MainActivity extends Activity {
  private WebView web; private ValueCallback<Uri[]> upload; private static final int PICK=721;
  @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);
    s.setAllowFileAccessFromFileURLs(true);s.setAllowUniversalAccessFromFileURLs(true);
    web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> cb,FileChooserParams params){
        if(upload!=null)upload.onReceiveValue(null);upload=cb;
        try{Intent i=params.createIntent();i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,PICK);return true;}
        catch(Exception ex){upload=null;cb.onReceiveValue(null);return false;}
      }
    });web.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(request!=PICK||upload==null)return;Uri[] resultUris=null;
    if(result==RESULT_OK&&data!=null){if(data.getClipData()!=null){int n=data.getClipData().getItemCount();resultUris=new Uri[n];for(int j=0;j<n;j++)resultUris[j]=data.getClipData().getItemAt(j).getUri();}else if(data.getData()!=null)resultUris=new Uri[]{data.getData()};}
    upload.onReceiveValue(resultUris);upload=null;
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
