package com.mk.afterpayscanner;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;

public class MainActivity extends Activity {
  private static final int FILE_CHOOSER_CODE=1337;
  private WebView webView;
  private ValueCallback<Uri[]> uploadCallback;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    webView = new WebView(this);
    setContentView(webView);
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(true);
    settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    webView.setWebViewClient(new WebViewClient());
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if(uploadCallback!=null) uploadCallback.onReceiveValue(null);
        uploadCallback=callback;
        try { startActivityForResult(params.createIntent(), FILE_CHOOSER_CODE); return true; }
        catch(Exception e) { uploadCallback=null; return false; }
      }
    });
    webView.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_CHOOSER_CODE && uploadCallback!=null) {
      uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
      uploadCallback=null;
    }
  }
  @Override public void onBackPressed() { if(webView!=null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
