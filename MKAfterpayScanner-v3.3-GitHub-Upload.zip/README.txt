MKAfterpayScanner v3.3 (Consistent OCR) APK source bundle.
Upload this ZIP to the ROOT of the MKAPSCanner repository (not MKmoney),
then replace .github/workflows/main.yml with the supplied workflow.
Run the GitHub Actions workflow (or push these files) and retrieve the debug APK artifact.
The OCR engine is fetched from a CDN when scanning; network may be needed.
Do not uninstall an earlier app without exporting its JSON data first.
This source bundle is not itself an APK.
