# IMPORTANT: Use a NEW GitHub repository

**Repository name must be `MKAfterpayScanner`. Do NOT upload into `MKmoney`.** GitHub Actions runs in the repository containing the workflow. Changing the Android package ID alone will not redirect GitHub Actions to another repository.

1. GitHub → **+** → **New repository** → name `MKAfterpayScanner` → **Create repository**.
2. Extract this ZIP and upload all its contents to **MKAfterpayScanner**, keeping the `android/` and `.github/workflows/` folder paths intact. Commit changes to `main`.
3. In **MKAfterpayScanner** open **Actions → Build MKAfterpayScanner APK v2.8 → Run workflow** (or wait for the push workflow).
4. In the completed Actions run download the artifact **MKAfterpayScanner-v2.8-debug-apk**, unzip it, and install **MKAfterpayScanner-v2.8-debug.apk**.

**Safety check:** The workflow will refuse to build in any repository other than `MKAfterpayScanner`.
**Android application ID:** `com.mkafterpayscanner.app`; label: `MKAfterpayScanner`.

---

# MKAfterpayScanner v2.8

Upload the **contents** of this folder to the root of a GitHub repository (or extract the ZIP before uploading). Turn on **Settings → Pages → Deploy from branch → main / (root)** to publish the static web app. Open the Pages URL on your phone and use the browser menu **Add to Home screen** to use the included logo as the app icon.

## Files
- `index.html` — latest scanner with long-image tiling, date selection, correction review and date tabs
- `logo.svg` and `logo.png` — app logo
- `icons/icon-192.png`, `icons/icon-512.png` — home-screen app icons
- `manifest.webmanifest` — web app metadata

## Important notes
- OCR uses Tesseract.js **loaded via internet/CDN on first use** and may require connectivity if browser cache is cleared; this is not a fully self-contained offline OCR installation. Screenshots are processed in your browser.
- Payment records are stored via browser `localStorage` and may not transfer to a new origin/browser. Export **Save records (JSON)** from your old version, then import in the new version when needed.
- Inspect OCR totals against the original Afterpay screenshots.
- This ZIP contains the **web app and a GitHub Actions workflow to build an Android APK**. The APK is created in GitHub Actions; download it from the successful workflow run’s Artifacts section.

## Build Android APK from GitHub
1. Upload **all files including the hidden `.github/workflows/build-apk.yml` folder** into the repository root. Do not upload the ZIP without extracting it.
2. Open **Actions → Build MKAfterpayScanner APK v2.8 → Run workflow**, or push to `main`.
3. Once green, open the run → **Artifacts** → **MKAfterpayScanner-v2.8-debug-apk**. Unzip and install `MKAfterpayScanner-v2.8-debug.apk` on your Android phone.
4. This is a **debug APK**, not signed for Google Play publishing.

**APK caveats:** The local app still needs network access to load the Tesseract OCR CDN resources. Browser-style `blob:` CSV/JSON downloads are not supported in this basic Android WebView shell (Copy breakdown works); use the GitHub Pages/browser version for exports. App data is stored inside the APK WebView and does not automatically migrate from the browser.
