# MKAfterpayScanner v2.9

Based on the **index.html and icons recovered from the uploaded successful v2.8 APK**, not on the unsuccessful v2.8 source revisions.

## Changes
- Supports multiple nonconsecutive selected repayment dates, individual date subtotals and all-dates totals (retained from v2.8).
- Keeps existing OCR overlapping screenshot tiles and duplicate detection (retained from v2.8).
- Stop Scan: requests cancellation after the current OCR section; completed scan results stay saved.
- Clear Attachments: removes selected images only, with confirmation.
- Saved identification dropdown in the review form; add a new merchant identification by typing it and confirming.
- Saved merchant identifications stored separately from repayment records.

## GitHub deployment
Upload the **contents** of this ZIP to the repository root (not the ZIP itself), replacing `.github/workflows/main.yml` and all application files. Use Actions → Build MKAfterpayScanner APK v2.9 → Run workflow. Download the debug APK from the build's Artifacts section.

## Limitations
OCR uses a CDN-hosted Tesseract.js package and language data on first use and therefore is not guaranteed completely offline. The APK build has not been executed in this environment; GitHub Actions will compile it. Back up/export existing JSON records before installing. For the same application ID and continuity, an APK signed with a different debug key will require uninstalling the previous APK, which removes its local data. Debug builds from different GitHub environments may have different signing keys. Verify package ID / signing compatibility before replacing an installed app.
