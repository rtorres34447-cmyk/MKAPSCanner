MKAfterpayScanner v3.3.1 (file picker + app logo fix)

What changed:
- Improved Android WebView screenshot picker support.
- Added proper app launcher logo/icons.
- Included manifest.webmanifest and web icons for packaging.
- Kept the existing scanner HTML and OCR logic intact.

Upload this ZIP to the ROOT of the MKAPSCanner repository,
replace .github/workflows/main.yml with the supplied workflow,
then run the GitHub Actions workflow and download the APK artifact.
